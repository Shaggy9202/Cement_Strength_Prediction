# Cement_Strength_Prediction
Data Description
Given is the variable name, variable type, the measurement unit and a brief description. 
The concrete compressive strength is the regression problem. The order of this listing 
corresponds to the order of numerals along the rows of the database. 

Deployment

We will be deploying the model to the Google Cloud Web Services Platform. 
application link: https://orbital-citizen-316919.uc.r.appspot.com/ 
However due to free tier restrictions, the application is disabled for now.
